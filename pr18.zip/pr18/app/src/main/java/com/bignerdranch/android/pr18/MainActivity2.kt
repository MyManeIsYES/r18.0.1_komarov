package com.bignerdranch.android.pr18

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
    lateinit var button: Button
    lateinit var button1: Button
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var pref: SharedPreferences
    var count=0
    var str=""

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        button=findViewById(R.id.BUTTON)
        button1=findViewById(R.id.BUTTON1)
        login=findViewById(R.id.log)
        password=findViewById(R.id.pass)
        pref=getPreferences(MODE_PRIVATE)
        login.setText(pref.getString("login$count","").toString())

        button.setOnClickListener { view: View ->
            try
            {
                pref=getPreferences(MODE_PRIVATE)
                var str0=pref.getString("login$count","").toString()
                var str1=pref.getString("password$count","").toString()
                login.setText(str0)
                var log=login.text.toString()
                var pass=password.text.toString()
                if(Check_text(log) && Check_text(pass)){


                    if(str0==log && str1==pass){
                        val intent = Intent(this@MainActivity2,MainActivity3::class.java)
                        startActivity(intent)
                    }
                    else{

                        if(str0==log){
                            if(str1==pass){

                            }
                            else Toast.makeText(this, "Неправильный пароль", Toast.LENGTH_SHORT).show()
                        }
                        else Toast.makeText(this, "Неправильный логин", Toast.LENGTH_SHORT).show()
                    }


                }
                else
                    if(Check_text(log)){
                        if(Check_text(pass)){
                        }
                        else Toast.makeText(this, "Поле Password пустое", Toast.LENGTH_SHORT).show()
                    }
                    else Toast.makeText(this, "Поле Login пустое", Toast.LENGTH_SHORT).show()
                //pref.getString("login$count",str)
                //pref.getString("password$count",str)
            }
            catch (e:NumberFormatException){
                Toast.makeText(this, "Нет такого пользователя", Toast.LENGTH_SHORT).show()
            }



        }
        button1.setOnClickListener { viev:View->

            pref=getPreferences(MODE_PRIVATE)
            var prefEditor=pref.edit()
            var log=login.text.toString()
            var pass=password.text.toString()
            if(Check_text(log) && Check_text(pass)){
                prefEditor.putString("login$count",log)
                prefEditor.putString("password$count",pass)
                prefEditor.apply()
                Toast.makeText(this, "Регистрация прошла успешно", Toast.LENGTH_SHORT).show()
            }
            else
                if(Check_text(log)){
                    if(Check_text(pass)){
                    }
                    else Toast.makeText(this, "Поле Password пустое", Toast.LENGTH_SHORT).show()
                }
                else Toast.makeText(this, "Поле Login пустое", Toast.LENGTH_SHORT).show()

        }

    }

    private fun Check_text(str: String): Boolean {
        return str!=""
    }
}